# Image_Stitching
This model helps in composing two images with a narrow but overlapping fields of view to create a larger image with a wider field of view .i.e, panaromic view
